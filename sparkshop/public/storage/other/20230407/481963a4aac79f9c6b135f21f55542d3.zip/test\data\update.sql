ALTER TABLE `sp_plugin_test`
ADD COLUMN `update_time` datetime(0) NULL AFTER `create_time`;