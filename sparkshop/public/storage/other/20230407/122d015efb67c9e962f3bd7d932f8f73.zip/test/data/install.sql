INSERT INTO `sp_admin_node`(`pid`, `type`, `name`, `path`, `icon`, `is_menu`, `sort`, `status`, `create_time`, `update_time`) VALUES (105, 'test', '测试管理', 'addons/test/admin.index/index', 'el-icon-mouse', 2, 0, 1, '2023-04-07 22:55:54', NULL);
CREATE TABLE `sp_plugin_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;