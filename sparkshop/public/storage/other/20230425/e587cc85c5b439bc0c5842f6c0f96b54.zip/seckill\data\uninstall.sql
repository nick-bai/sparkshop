DROP TABLE IF EXISTS `<#PREFIX#>seckill_activity`;
DROP TABLE IF EXISTS `<#PREFIX#>seckill_activity_goods`;
DROP TABLE IF EXISTS `<#PREFIX#>seckill_order`;
DROP TABLE IF EXISTS `<#PREFIX#>seckill_time`;