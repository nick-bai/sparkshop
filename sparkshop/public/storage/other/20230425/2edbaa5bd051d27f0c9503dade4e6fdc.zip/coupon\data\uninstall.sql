DROP TABLE IF EXISTS `<#PREFIX#>coupon`;
DROP TABLE IF EXISTS `<#PREFIX#>coupon_goods`;
DROP TABLE IF EXISTS `<#PREFIX#>coupon_receive_log`;